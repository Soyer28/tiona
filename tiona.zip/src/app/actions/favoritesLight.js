import { createAction } from 'redux-actions';


export const FAVORITESLIGHT_SUCCESS = createAction('FAVORITESLIGHT/SUCCESS');
export const FAVORITESLIGHT_FAILURE = createAction('FAVORITESLIGHT/FAILURE');
export const FAVORITESLIGHT_REQUEST = createAction('FAVORITESLIGHT/REQUEST');
