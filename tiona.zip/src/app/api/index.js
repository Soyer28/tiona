import {configure, RestError} from './helpers';
import * as api from './api';

export {
  RestError,
  configure,
  api
};
