import AppLayout from './appLayout.container';

export default AppLayout;