import LogsBlock from './logsBlock.container';

export default LogsBlock;