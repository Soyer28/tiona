import Strategy1View from './strategy1Edit.container';
import NewStrategy from './strategy1New.container';

export default Strategy1View;

export {NewStrategy};