import FavoritesLight from '../../components/favoritesLight';

export default FavoritesLight;
