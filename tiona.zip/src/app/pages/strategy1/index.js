import Strategy1 from '../../components/strategy1';

export default Strategy1;
