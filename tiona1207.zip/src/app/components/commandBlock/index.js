import Strategy1 from './strategy1.container';

export default Strategy1;