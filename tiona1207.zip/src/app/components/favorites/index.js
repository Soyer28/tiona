import Favorites from './favorites.container';

export default Favorites;
