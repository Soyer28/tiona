import FavoritesLight from './favoritesLight.container';

export default FavoritesLight;
