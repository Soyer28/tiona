import Indicators from './indicators.container';

export default Indicators;