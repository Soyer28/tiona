import LevelsConfig from './levelsConfig';

export default LevelsConfig;