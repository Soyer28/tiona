import Strategy1View from './strategy1View.container';

export default Strategy1View;

