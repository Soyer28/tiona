import Favorites from '../../components/favorites';

export default Favorites;
