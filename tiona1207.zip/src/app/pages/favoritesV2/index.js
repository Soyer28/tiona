import Favorites from '../../components/favoritesV2';

export default Favorites;
