import Indicators from '../../components/indicators';

export default Indicators;
