import LoginPage from './loginPage.container';

export default LoginPage;
