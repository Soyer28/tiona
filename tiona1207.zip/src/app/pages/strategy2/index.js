import Strategy2 from '../../components/strategy2';

export default Strategy2;
