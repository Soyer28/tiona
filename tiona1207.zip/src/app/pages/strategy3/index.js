import Strategy3 from '../../components/strategy3';

export default Strategy3;
